import React, { useEffect, useState } from 'react'
import { supabase } from '../supabaseClient'
import { useNavigate } from 'react-router-dom'

export default function ProtectedRoute({children}){
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)

  useEffect(()=>{
    supabase.auth.getSession().then(({data})=>{
      if(!data?.session) navigate('/login')
      setLoading(false)
    })
  },[])

  if(loading) return <div className='container'>Loading...</div>
  return children
}
