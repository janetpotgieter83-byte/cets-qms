import React, {useState} from 'react'
import { supabase } from '../supabaseClient'

export default function DocumentUpload({onUploaded}){
  const [file, setFile] = useState(null)
  const [title, setTitle] = useState('')
  const [uploading, setUploading] = useState(false)

  async function upload(){
    if(!file || !title) return alert('Provide title and file')
    setUploading(true)
    const fileName = `${Date.now()}_${file.name}`
    const { data, error: uploadError } = await supabase.storage.from('documents').upload(fileName, file)
    if(uploadError){
      setUploading(false)
      return alert(uploadError.message)
    }
    const { data: urlData } = supabase.storage.from('documents').getPublicUrl(data.path)
    const user = await supabase.auth.getUser().then(r=>r.data.user)
    const userId = user?.id || null
    const { error } = await supabase.from('documents').insert([{ title, file_url: urlData.publicUrl, uploaded_by: userId, version: 1, status: 'Draft' }])
    setUploading(false)
    if(error) return alert(error.message)
    setTitle('')
    setFile(null)
    onUploaded && onUploaded()
  }

  return (
    <div className='card'>
      <h3>Upload Document</h3>
      <input className='mb' placeholder='Document Title' value={title} onChange={e=>setTitle(e.target.value)} />
      <div style={{margin:'8px 0'}}><input type='file' onChange={e=>setFile(e.target.files[0])} /></div>
      <div><button onClick={upload} disabled={uploading}>{uploading?'Uploading...':'Upload'}</button></div>
    </div>
  )
}
