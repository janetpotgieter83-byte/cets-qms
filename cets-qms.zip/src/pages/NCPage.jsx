import React, {useState, useEffect} from 'react'
import { supabase } from '../supabaseClient'

export default function NCPage(){
  const [ncs, setNcs] = useState([])
  const [desc, setDesc] = useState('')

  async function load(){
    const { data, error } = await supabase.from('non_conformances').select('*').order('created_at',{ascending:false})
    if(error) return alert(error.message)
    setNcs(data)
  }

  useEffect(()=>{ load() },[])

  async function raise(){
    if(!desc) return alert('Describe the non-conformance')
    const user = await supabase.auth.getUser().then(r=>r.data.user)
    const { error } = await supabase.from('non_conformances').insert([{ description: desc, reported_by: user?.id || null, status: 'Open' }])
    if(error) return alert(error.message)
    setDesc('')
    load()
  }

  return (
    <div className='container'>
      <div style={{display:'flex', gap:16}}>
        <div style={{flex:1}}>
          <div className='card'>
            <h3>Raise NC</h3>
            <textarea style={{width:'100%', minHeight:120}} value={desc} onChange={e=>setDesc(e.target.value)} />
            <div style={{marginTop:8}}><button onClick={raise}>Submit</button></div>
          </div>
        </div>
        <div style={{flex:1}}>
          <div className='card'>
            <h3>Open NCs</h3>
            <ul>
              {ncs.map(n=> (
                <li key={n.id} style={{marginBottom:8}}>
                  <div style={{fontWeight:600}}>{n.description}</div>
                  <div style={{fontSize:12, color:'#6b7280'}}>{n.status}</div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
