import React, {useEffect, useState} from 'react'
import { supabase } from '../supabaseClient'
import { Link } from 'react-router-dom'

export default function Dashboard(){
  const [counts, setCounts] = useState({docs:0, ncs:0})
  async function load(){
    const { data: docs, count: docsCount } = await supabase.from('documents').select('*', { count: 'exact' })
    const { data: ncs, count: ncsCount } = await supabase.from('non_conformances').select('*', { count: 'exact' })
    setCounts({ docs: docs?.length || 0, ncs: ncs?.length || 0 })
  }
  useEffect(()=>{ load() },[])
  return (
    <div className='container'>
      <div className='header'>
        <div><img src='/logo.jpg' alt='logo' style={{height:48}} /> <strong style={{marginLeft:12}}>C.E.T.S Quality Management System</strong></div>
        <div><Link to='/documents'>Documents</Link> | <Link to='/ncs'>Non-Conformances</Link></div>
      </div>
      <div style={{marginTop:20}}>
        <div className='card' style={{marginBottom:12}}>
          <h3>Overview</h3>
          <div>Documents: {counts.docs}</div>
          <div>Open NCs: {counts.ncs}</div>
        </div>
      </div>
    </div>
  )
}
