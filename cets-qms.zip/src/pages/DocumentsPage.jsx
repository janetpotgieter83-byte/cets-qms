import React, {useEffect, useState} from 'react'
import DocumentUpload from '../components/DocumentUpload'
import { supabase } from '../supabaseClient'

export default function DocumentsPage(){
  const [docs, setDocs] = useState([])

  async function load(){
    const { data, error } = await supabase.from('documents').select('*').order('created_at', { ascending: false })
    if(error) return alert(error.message)
    setDocs(data)
  }

  useEffect(()=>{ load() },[])

  return (
    <div className='container'>
      <div style={{display:'flex', gap:16}}>
        <div style={{flex:1}}>
          <DocumentUpload onUploaded={load} />
        </div>
        <div style={{flex:1}}>
          <div className='card'>
            <h3>Library</h3>
            <ul>
              {docs.map(d=> (
                <li key={d.id} style={{marginBottom:8}}>
                  <div><strong>{d.title}</strong></div>
                  <div style={{fontSize:12, color:'#6b7280'}}>Version {d.version} — {d.status}</div>
                  <div style={{marginTop:6}}><a href={d.file_url} target='_blank'>Open</a></div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
