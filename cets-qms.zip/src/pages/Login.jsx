import React, {useState} from 'react'
import { supabase } from '../supabaseClient'

export default function Login(){
  const [email,setEmail] = useState('')
  const [password,setPassword] = useState('')
  const [loading,setLoading] = useState(false)
  const [error,setError] = useState(null)

  async function signIn(e){
    e.preventDefault()
    setLoading(true)
    setError(null)
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    setLoading(false)
    if(error) setError(error.message)
    else window.location.href='/'
  }

  return (
    <div style={{display:'flex', minHeight:'100vh', alignItems:'center', justifyContent:'center', background:'#f3f4f6'}}>
      <form onSubmit={signIn} style={{background:'#fff', padding:24, borderRadius:8, boxShadow:'0 2px 8px rgba(0,0,0,0.08)', width:360}}>
        <div style={{textAlign:'center', marginBottom:12}}>
          <img src="/logo.jpg" alt="logo" style={{height:64}} />
          <h2>C.E.T.S Quality Management System</h2>
        </div>
        {error && <div style={{color:'#b91c1c', marginBottom:8}}>{error}</div>}
        <div style={{marginBottom:8}}>
          <label>Email</label>
          <input className='w-full' value={email} onChange={e=>setEmail(e.target.value)} />
        </div>
        <div style={{marginBottom:12}}>
          <label>Password</label>
          <input type='password' className='w-full' value={password} onChange={e=>setPassword(e.target.value)} />
        </div>
        <button style={{width:'100%', padding:10, background:'#1f2937', color:'#fff', border:'none', borderRadius:6}} disabled={loading}>{loading?'Signing in...':'Sign in'}</button>
      </form>
    </div>
  )
}
