import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import DocumentsPage from './pages/DocumentsPage'
import NCPage from './pages/NCPage'
import ProtectedRoute from './components/ProtectedRoute'

export default function App(){
  return (
    <Routes>
      <Route path='/login' element={<Login/>} />
      <Route path='/' element={<ProtectedRoute><Dashboard/></ProtectedRoute>} />
      <Route path='/documents' element={<ProtectedRoute><DocumentsPage/></ProtectedRoute>} />
      <Route path='/ncs' element={<ProtectedRoute><NCPage/></ProtectedRoute>} />
      <Route path='*' element={<Navigate to='/' />} />
    </Routes>
  )
}
